/*Riley Strasser 2/2/25*/
alert("Welcome To STRAÜSS Music"); 

function myFunction() {
    document.getElementById("ticketbutton").innerHTML = "No Tickets Available at this time.";
}

